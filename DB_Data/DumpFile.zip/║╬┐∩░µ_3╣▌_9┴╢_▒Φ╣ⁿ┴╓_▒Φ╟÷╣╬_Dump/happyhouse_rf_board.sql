-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhouse_rf
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `BOARD_ID` int NOT NULL AUTO_INCREMENT,
  `USER_SEQ` int NOT NULL,
  `TITLE` varchar(500) DEFAULT NULL,
  `CONTENT` text,
  `REG_DT` datetime DEFAULT NULL,
  `READ_COUNT` int DEFAULT '0',
  PRIMARY KEY (`BOARD_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (17,1,'서울에 살고 싶다!','취업하고 싶은데 괜찮은 방좀!','2021-11-24 15:55:49',1),(18,1,'ㅇㅇㅇㅇㅇ','ㅇㅇㅇ','2021-11-26 03:54:50',0),(19,1,'ㄴㅁㅎㅇㄴㅁㅎㅇㄴㅎㅇㄴ','ㅎㅁㄴㅎㄴㅇㅎㅁ','2021-11-26 03:54:52',0),(20,1,'ㄴㅇㅁㄹㅁㅇㄴㅎㄷㅎㅎ','ㅎㄴㅎㅁㄴㄷㅎㅁㄴㅎㄷㄴㅁㅎㅁㄴㄷㅎㄷㄴㅁㅎ','2021-11-26 03:54:56',0),(21,1,'ㅁㄴㅇㅎㅁㄴㅇㅎㄴㅇㅎㅁㅇㄴ','ㅎㄴㅇㅁㅎㄴㅇㅁㅎㅁㅇㄴㅎㄴㅎ','2021-11-26 03:54:59',0),(22,1,'','','2021-11-26 03:55:08',0),(23,1,'ㅁㄴㅇㅎㅇㄴㅁㅎㅇㅁㄴㅎㅇㄴㅁㅎ','ㄴㅎㅁㄴㅎㅁㄴㅇㅎ','2021-11-26 03:55:12',0),(24,1,'ㄷㅈㅅㄷㅂㅈㅅㄷㅈㅅㅈㅂㅅ','ㅂㄷㅈㅅㅈㄷㅂㅅㅂㄷㅈㅅ','2021-11-26 03:55:15',0),(25,1,'ㅂㅈㄷㅅㅂㄷㅈㅅㄷㅂㅈㅅㄷㅈㅂㅅ','ㅈㅂㄷㅅㄷㅈㅂㅅㅈㄷㅅㅂㅅ','2021-11-26 03:55:18',0),(27,1,'ㅂㅈㄷㅅㅈㅂㅅㅈㄷㅅㅂㅈㄷㅅㄷㅈㅅㅂㅈㅅ','ㅈㅂㅅㅂㅈㄷㅅㄷㅈㅂㅅㄷㅈㅅ','2021-11-26 03:55:29',1),(28,1,'ㄴㅁㅎㄴㅎㅇㄴㅎㄴㅇㅎㅇㄴㅎㅇㄴㅎㄴㅎㅇㄴ','ㄴㅇㅎㅇㄴㅎㄴㅇㅎㅇㄴㅎㅇㄴㅎㄴㅇㅎ','2021-11-26 03:55:34',0),(29,1,'ㄴㅇㅁㅎㄴㅎㄴㅇㅁㅎㅁㅇㄴㅎㅎㄴ','ㅎㄴㅇㅎㄴㅎㅎㄴㅇㅎㅎ','2021-11-26 03:55:40',0),(30,1,'ㅁㄴㅎㅁㅇㄴㅎㄴㅇㅁㅎㅇㄴㅇㄴㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ','ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ','2021-11-26 03:55:47',1),(31,2,'열심히 만들었습니다!!!!!!!','시간이 조금만 더 있었으면 더 좋은 결과물을!!!!!!','2021-11-26 06:13:30',1),(32,1,'자유게시판입니다!','자유게시판!','2021-11-26 07:50:00',1);
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26  8:01:46
