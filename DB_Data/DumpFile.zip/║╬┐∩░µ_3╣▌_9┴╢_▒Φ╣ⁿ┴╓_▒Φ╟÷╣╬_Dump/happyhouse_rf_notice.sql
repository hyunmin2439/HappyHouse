-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: happyhouse_rf
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `notice_seq` int NOT NULL AUTO_INCREMENT,
  `notice_title` varchar(50) NOT NULL,
  `notice_userseq` varchar(45) NOT NULL,
  `notice_content` varchar(200) NOT NULL,
  `notice_readcount` int NOT NULL,
  `notice_regdt` datetime DEFAULT NULL,
  PRIMARY KEY (`notice_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (29,'안녕하세요 첫공지입니다.','2','안녕하세요',1,'2021-11-24 10:39:00'),(30,'1','2','21231',0,'2021-11-26 04:29:49'),(31,'21221','2','1211221',0,'2021-11-26 04:29:53'),(32,'123123213','2','123123',0,'2021-11-26 04:29:55'),(33,'123123213','2','123123',0,'2021-11-26 04:29:57'),(34,'12312321','2','3123123',1,'2021-11-26 04:30:00'),(35,'12312321','2','3123123',1,'2021-11-26 04:30:02'),(36,'12312321','2','312321312321',0,'2021-11-26 04:30:05'),(37,'12312312321321','2','31231232',1,'2021-11-26 04:30:08'),(38,'123123213123213321','2','31231231232',1,'2021-11-26 04:30:12'),(39,'123123123123213','2','123123213123',0,'2021-11-26 04:30:19'),(40,'12312321321321321','2','3123123213213',0,'2021-11-26 04:30:23'),(41,'1231312312','2','3123123213213123',0,'2021-11-26 04:30:27'),(42,'12312312','2','3123123213',0,'2021-11-26 04:30:30'),(43,'시간이 부족해 허허허어엉','2','거의 다만들었는데',0,'2021-11-26 06:13:44'),(44,'교수님 정말 정말 감사했습니다! 많은 걸 배워갑니다!','2','교수님 정말 정말 감사했습니다! 많은 걸 배워갑니다! 반응도 잘 안 해주는 선비들을 대상으로 교육하신다고 정말 고생많으셨습니다!',1,'2021-11-26 06:14:24');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26  8:01:48
